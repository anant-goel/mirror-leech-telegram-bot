
init.miui.early_boot.sh ( its located in / )

add at the end:

rm -rf /data/dalvik-cache/*



Now in system/framework/arm and system/framework/arm64 search and delete these files:

boot-framework.art
boot-framework.oat

